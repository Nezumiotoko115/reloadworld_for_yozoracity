fx_version 'cerulean'
game 'gta5'

author 'reloadworld contributors'
description 'Standalone, safety-first local world streaming recovery helper'
version '1.3.2'

shared_script 'config.lua'
client_script 'client.lua'
server_script 'server.lua'

